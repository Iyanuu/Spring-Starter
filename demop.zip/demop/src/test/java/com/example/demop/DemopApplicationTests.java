package com.example.demop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemopApplicationTests {

	@Test
	void contextLoads() {
	}

}
