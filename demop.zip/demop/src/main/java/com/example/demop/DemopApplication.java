package com.example.demop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemopApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemopApplication.class, args);
	}

}
